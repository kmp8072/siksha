# README #


### enrolment on course completed

* Quick summary : Course completed enrolment handles the enrolment of users upon completion of another course.
* With this plugin it is possible to create a chain of courses.  The moment a student completes a course, he/she
  is automatically enrolled in one or more courses. But it can also be used to give a user another role when he/she
  completes the course.

* Maturity: Beta code

* TODO: role exist check

![travis](https://travis-ci.org/ewallah/moodle-enrol_coursecompleted.svg)