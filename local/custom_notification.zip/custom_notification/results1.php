
<?php

require_once (dirname(dirname(dirname(__FILE__))) . '/config.php');


$courseid=$_GET['courseid'];
$message=$_GET['message'];

echo $message;

?>
             
<!-- <script type="text/javascript">
	
	var abc="<?php echo $message; ?>";

	console.log(abc);

</script> -->

